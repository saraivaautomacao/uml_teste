Desktop Boss Icons

This archive contains selected icons from Desktop Boss Icons set that can be found here:
http://www.desktop-icon.com/stock-icons/desktop-boss-icons.htm

All free icons contained in this archive are licensed under a Creative Commons Attribution-Share Alike 3.0 License. This means that you can freely use these icons for any personal and non-ommercial purposes (software interfaces, online services, blogs, templates etc.) while you include a link to www.aha-soft.com in your credits.

If you wish to use any icon from this set in a commercial product, please follow this link to purchase it:
http://www.desktop-icon.com/stock-icons/desktop-boss-icons.htm